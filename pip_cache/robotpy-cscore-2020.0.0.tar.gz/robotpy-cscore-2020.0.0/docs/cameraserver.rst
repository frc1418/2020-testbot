CameraServer
------------

.. autoclass:: cscore.CameraServer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: cscore.VideoException
    :members:
