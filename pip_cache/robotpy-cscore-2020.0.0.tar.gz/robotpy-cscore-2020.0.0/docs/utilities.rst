Utilities
---------

.. autoclass:: cscore.imagewriter.ImageWriter
    :members:

