class Info:
    def module_info(self):
        from cscore import __version__

        return "cscore", __version__
